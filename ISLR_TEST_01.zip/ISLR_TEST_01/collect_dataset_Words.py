# iloveu
# hello/hi
# thankyou/thanks
# welcome


import os
import cv2
cap=cv2.VideoCapture(0)
directory='Image/'
while True:
    _,frame=cap.read() #open cam
    count = {
             'i': len(os.listdir(directory+"/IloveU")),
             'h': len(os.listdir(directory+"/Hello")),
             't': len(os.listdir(directory+"/Thankyou")),
             'w': len(os.listdir(directory+"/Welcome")),
             
             } #count files in dir
    row = frame.shape[1]
    col = frame.shape[0]
    cv2.rectangle(frame,(0,40),(300,400),(255,255,255),2) #gui
    cv2.imshow("data",frame)
    cv2.imshow("ROI",frame[40:400,0:300])
    frame=frame[40:400,0:300]
    interrupt = cv2.waitKey(10)
    if interrupt & 0xFF == ord('i'): #save img
        cv2.imwrite(directory+'IloveU/'+str(count['i'])+'.jpg',frame)
        print(f"Captured: IloveU({count['i']})")
    if interrupt & 0xFF == ord('h'):
        cv2.imwrite(directory+'Hello/'+str(count['h'])+'.jpg',frame)
        print(f"Captured: Hello({count['h']})")
    if interrupt & 0xFF == ord('t'):
        cv2.imwrite(directory+'Thankyou/'+str(count['t'])+'.jpg',frame)
        print(f"Captured: Thankyou({count['t']})")
    if interrupt & 0xFF == ord('w'):
        cv2.imwrite(directory+'Welcome/'+str(count['w'])+'.jpg',frame)
        print(f"Captured: Welcome({count['w']})")

cap.release()
cv2.destroyAllWindows() #exit